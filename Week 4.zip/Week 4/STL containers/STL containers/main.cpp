#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
using namespace std;

class PeopleList {
private:
    vector<string> allNames;
    map<string, int> ageMap;
    int total, ageInput, ageLimit;
    string nameInput;

public:
    void inputPeople() {
        cout << "How many people you want to enter?" << endl;
        cin >> total;
        cin.ignore();
        enterNameAge(total);
    }

    void enterNameAge(int count) {
        for (int i = 0; i < count; i++) {
            cout << "Type name: ";
            getline(cin, nameInput);
            cout << "Type age: ";
            cin >> ageInput;
            cin.ignore();
            allNames.push_back(nameInput);
            ageMap[nameInput] = ageInput;
        }
    }

    void askAgeLimit() {
        cout << "Enter age to find people older than that: ";
        cin >> ageLimit;
        showOlder(ageLimit);
    }

    void showOlder(int limit) {
        cout << "People older than " << limit << " are:" << endl;
        for (auto it : ageMap) {
            if (it.second > limit) {
                cout << "Name: " << it.first << ", Age: " << it.second << endl;
            }
        }
    }

    void showSortedNames() {
        sort(allNames.begin(), allNames.end());
        cout << "Sorted names:" << endl;
        for (string n : allNames) {
            cout << n << endl;
        }
    }
};

int main() {
    PeopleList myPeople;
    myPeople.inputPeople();
    myPeople.askAgeLimit();
    myPeople.showSortedNames();
    return 0;
}

