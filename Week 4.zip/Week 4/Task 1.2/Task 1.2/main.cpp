#include <iostream>
using namespace std;

class MyStack {
private:
    int data[10];
    int topIndex;
    int toPop;

public:
    MyStack() {
        topIndex = -1;
    }

    void addItems() {
        cout << "Put 10 numbers into the stack = " << endl;
        for (int i = 0; i < 10; i++) {
            cin >> data[i];
        }
        topIndex = 9;
    }

    void removeItems() {
        cout << "How many numbers you want to take out (pop)? ";
        cin >> toPop;
        while (toPop > topIndex + 1) {
            cout << "Not enough items Please Try again = ";
            cin >> toPop;
        }
        for (int i = 0; i < toPop; i++) {
            cout << "Removed = " << data[topIndex] << endl;
            topIndex--;
        }
    }

    void showMiddle() {
        if (topIndex == -1) {
            cout << "Stack is empty, no middle." << endl;
            return;
        }
        int middle = (topIndex + 1) / 2;
        cout << "Middle number is = " << data[middle] << endl;
    }

    void flipBottomHalf() {
        int middle = (topIndex + 1) / 2;
        for (int i = 0; i < middle / 2; i++) {
            int temp = data[i];
            data[i] = data[middle - 1 - i];
            data[middle - 1 - i] = temp;
        }

        cout << "Stack after flipping bottom half = " << endl;
        for (int i = 0; i <= topIndex; i++) {
            cout << data[i] << " ";
        }
        cout << endl;
    }
};

int main() {
    MyStack stacky;
    stacky.addItems();
    stacky.removeItems();
    stacky.showMiddle();
    stacky.flipBottomHalf();
    return 0;
}

