#include <iostream>
using namespace std;

class SimpleQueue {
private:
    int* data;
    int front, rear, size, maxSize;

public:
    SimpleQueue(int cap) {
        maxSize = cap;
        data = new int[maxSize];
        front = -1;
        rear = -1;
        size = 0;
    }

    ~SimpleQueue() {
        delete[] data;
    }

    void fillQueue() {
        int howMany;
        cout << "How many numbers to put in queue? ";
        cin >> howMany;
        cout << "Enter numbers:" << endl;
        for (int i = 0; i < howMany; i++) {
            int val;
            cin >> val;
            put(val);
        }
    }

    void put(int val) {
        if (size == maxSize) {
            cout << "Queue is full! Can't add more." << endl;
            return;
        }
        if (front == -1) {
            front = 0;
        }
        rear = (rear + 1) % maxSize;
        data[rear] = val;
        size++;
    }

    void showQueue() {
        cout << "Queue now: ";
        for (int i = 0; i < size; i++) {
            cout << data[(front + i) % maxSize] << " ";
        }
        cout << endl;
    }

    void removeItems() {
        int howMany;
        cout << "How many to take out (dequeue)? ";
        cin >> howMany;
        for (int i = 0; i < howMany; i++) {
            take();
        }
    }

    void take() {
        if (size == 0) {
            cout << "Queue is empty!" << endl;
            return;
        }
        cout << "Removed: " << data[front] << endl;
        front = (front + 1) % maxSize;
        size--;
        if (size == 0) {
            front = -1;
            rear = -1;
        }
        showQueue();
    }

    void reverseFirstK() {
        int k;
        cout << "Enter how many items from start to reverse: ";
        cin >> k;
        if (k > size) {
            cout << "Too many! Queue doesn't have that many." << endl;
            return;
        }

        for (int i = 0; i < k / 2; i++) {
            int idx1 = (front + i) % maxSize;
            int idx2 = (front + k - 1 - i) % maxSize;
            int temp = data[idx1];
            data[idx1] = data[idx2];
            data[idx2] = temp;
        }

        cout << "Queue after reversing first " << k << " items: ";
        showQueue();
    }

    void mixHalves() {
        if (size % 2 != 0) {
            cout << "Queue has odd number, can't interleave." << endl;
            return;
        }

        int half = size / 2;
        int firstPart[maxSize], secondPart[maxSize];
        for (int i = 0; i < half; i++) {
            firstPart[i] = data[(front + i) % maxSize];
            secondPart[i] = data[(front + half + i) % maxSize];
        }

        front = -1;
        rear = -1;
        size = 0;

        for (int i = 0; i < half; i++) {
            put(firstPart[i]);
            put(secondPart[i]);
        }

        cout << "Queue after mixing two halves: ";
        showQueue();
    }
};

int main() {
    int cap;
    cout << "What's the max size of the queue? ";
    cin >> cap;

    SimpleQueue q(cap);
    q.fillQueue();
    q.showQueue();
    q.removeItems();
    q.take(); // extra dequeue call
    q.reverseFirstK();
    q.mixHalves();

    return 0;
}


