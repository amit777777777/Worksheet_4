#include<iostream>
using namespace std;

class MyNode {
public:
    int data;
    MyNode* next;
    MyNode(int val) {
        data = val;
        next = NULL;
    }
};

class MyList {
    MyNode* head;
public:
    MyList() {
        head = NULL;
    }

    void addFirst(int val) {
        MyNode* n = new MyNode(val);
        n->next = head;
        head = n;
    }

    void addLast(int val) {
        MyNode* n = new MyNode(val);
        if (head == NULL) {
            head = n;
            return;
        }
        MyNode* temp = head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = n;
    }

    void addAtPos(int val, int pos) {
        if (pos == 0) {
            addFirst(val);
            return;
        }
        MyNode* temp = head;
        for (int i = 0; i < pos - 1; i++) {
            if (temp == NULL) {
                cout << "Position out of range." << endl;
                return;
            }
            temp = temp->next;
        }
        MyNode* n = new MyNode(val);
        n->next = temp->next;
        temp->next = n;
    }

    void printList() {
        MyNode* temp = head;
        while (temp != NULL) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }

    void makeLoop() {
        if (head == NULL) return;
        MyNode* temp = head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = head->next; // loop made
    }

    bool findLoop() {
        MyNode* slow = head;
        MyNode* fast = head;
        while (fast != NULL && fast->next != NULL) {
            slow = slow->next;
            fast = fast->next->next;
            if (slow == fast) {
                cout << "Loop found!" << endl;
                return true;
            }
        }
        return false;
    }

    void fixLoop() {
        MyNode* slow = head;
        MyNode* fast = head;
        bool loopFound = false;

        while (fast != NULL && fast->next != NULL) {
            slow = slow->next;
            fast = fast->next->next;
            if (slow == fast) {
                loopFound = true;
                break;
            }
        }

        if (!loopFound) {
            cout << "No loop in list." << endl;
            return;
        }

        slow = head;
        if (slow == fast) {
            while (fast->next != slow) {
                fast = fast->next;
            }
        } else {
            while (slow->next != fast->next) {
                slow = slow->next;
                fast = fast->next;
            }
        }
        fast->next = NULL;
        cout << "Loop removed!" << endl;
    }

    void getNthFromEnd(int n) {
        MyNode* first = head;
        MyNode* second = head;

        for (int i = 0; i < n; i++) {
            if (second == NULL) {
                cout << "Not enough nodes!" << endl;
                return;
            }
            second = second->next;
        }

        while (second != NULL) {
            first = first->next;
            second = second->next;
        }

        cout << "Nth node from end is: " << first->data << endl;
    }

    MyNode* reverseK(MyNode* node, int k) {
        MyNode* prev = NULL;
        MyNode* curr = node;
        MyNode* next = NULL;
        int count = 0;

        while (curr != NULL && count < k) {
            next = curr->next;
            curr->next = prev;
            prev = curr;
            curr = next;
            count++;
        }

        if (next != NULL) {
            node->next = reverseK(next, k);
        }

        return prev;
    }

    void reverseInK(int k) {
        head = reverseK(head, k);
    }
};

int main() {
    MyList myL;

    // adding elements
    myL.addFirst(4);
    myL.addFirst(3);
    myL.addFirst(2);
    myL.addFirst(1);
    myL.addLast(6);
    myL.addAtPos(5, 4);  // add 5 at pos 4

    cout << "Original List: ";
    myL.printList();

    cout << "Creating loop to test..." << endl;
    myL.makeLoop();
    myL.fixLoop();

    cout << "List after loop fix: ";
    myL.printList();

    cout << "2nd from end: ";
    myL.getNthFromEnd(2);

    cout << "List after reversing in groups of 2: ";
    myL.reverseInK(2);
    myL.printList();

    return 0;
}

